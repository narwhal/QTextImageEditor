# QTextImage

This is an [ASCIImage](http://asciimage.org/) editor based on [QTextImage](https://www.github.com/narwhal/QTextImage).

See the [ASCIImage](http://asciimage.org/) website for documentation about the format and for other implementations.
